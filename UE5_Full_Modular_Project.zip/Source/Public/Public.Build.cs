
using UnrealBuildTool;

public class Public : ModuleRules
{
    public Public(ReadOnlyTargetRules Target) : base(Target)
    {
        PCHUsage = PCHUsageMode.UseExplicitOrSharedPCHs;

        PublicDependencyModuleNames.AddRange(
            new string[]
            {
                "Core",
                "CoreUObject",
                "Engine",
                "NetCore",
                "ReplicationGraph",
                "OnlineSubsystem",
                "OnlineSubsystemUtils"
            }
        );
    }
}


using UnrealBuildTool;

public class Private : ModuleRules
{
    public Private(ReadOnlyTargetRules Target) : base(Target)
    {
        PCHUsage = PCHUsageMode.UseExplicitOrSharedPCHs;

        PublicDependencyModuleNames.AddRange(
            new string[]
            {
                "Core",
                "CoreUObject",
                "Engine",
                "NetCore",
                "ReplicationGraph",
                "OnlineSubsystem",
                "OnlineSubsystemUtils"
            }
        );
    }
}


using UnrealBuildTool;

public class ResourceSystem : ModuleRules
{
    public ResourceSystem(ReadOnlyTargetRules Target) : base(Target)
    {
        PCHUsage = PCHUsageMode.UseExplicitOrSharedPCHs;

        PublicDependencyModuleNames.AddRange(
            new string[]
            {
                "Core",
                "CoreUObject",
                "Engine",
                "NetCore",
                "ReplicationGraph",
                "OnlineSubsystem",
                "OnlineSubsystemUtils"
            }
        );
    }
}
